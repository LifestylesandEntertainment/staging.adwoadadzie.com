To translate the theme, follow the tutorial at http://themify.me/docs/translating-themes
and save your .po and .mo files in this folder.