<!-- post-nav -->
<div class="post-nav clearfix"> 
	<?php previous_post_link('<span class="prev">%link</span>', '<span class="arrow">&laquo;</span> %title') ?>
	<?php next_post_link('<span class="next">%link</span>', '<span class="arrow">&raquo;</span> %title') ?>
</div>
<!-- /post-nav -->
